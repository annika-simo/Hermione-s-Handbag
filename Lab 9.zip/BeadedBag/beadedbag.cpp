#include <algorithm>
#include "beadedbag.h"
#include "item.h"
#include <vector>

// Implement the BeadedBag::size and BeadedBag::insert member functions here.

// Complete the implementation of the BeadedBag::contains member function.
bool BeadedBag::contains(Item maybe_contained_item) {
  return false;
}